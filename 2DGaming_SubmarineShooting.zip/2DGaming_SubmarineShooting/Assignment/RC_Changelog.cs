
// This is Just a chage log from 16/8/2019
/*
 *
 * 1.1.1 Change sprite to have a new constructor that allows a part of a texture (a source image frame) at creation 
 *
 * 1.1.2 Updated animation comments
 *
 * 1.1.3 Added  bool dragAndDrop { get; set; } and 
 *              bool dragAndDropState { get; set; }
 *
 * 1.1.4 Moved hotspotoffset to spte3parent
 *
 *
 *
 *
 *
 *  
 */
