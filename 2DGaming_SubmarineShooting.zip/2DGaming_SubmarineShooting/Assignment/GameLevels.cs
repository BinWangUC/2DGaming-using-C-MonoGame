﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;



using RC_Framework;

namespace Assignment
    {
    

    class Dir
    {
        public static string dir = ""; 
    }


    // -------------------------------------------------------- Game level 0 ----------------------------------------------------------------------------------
    class GameLevel_0 : RC_GameStateParent
    {
        Texture2D texBackground = null;
        Texture2D texBtnPlay = null;
        Texture2D texBtnHelp = null;
        Texture2D texBtnExit =null;
        MouseState mouseState;
        MouseState prevMouseState;
        int mouseX, mouseY;

        TextRenderableBordered btnPlay = null;
        TextRenderableBordered btnHelp = null;
        TextRenderableBordered btnExit = null;

        public override void LoadContent()
        {
            LineBatch.init(graphicsDevice);
            font1 = Content.Load<SpriteFont>("Fonty");
            texBackground = Util.texFromFile(graphicsDevice, Dir.dir + "level0_1.jpg");

            texBtnPlay = Util.texFromFile(graphicsDevice, Dir.dir + "GreenPlay.bmp");
            texBtnHelp = Util.texFromFile(graphicsDevice, Dir.dir + "GreenHelp.bmp");
            texBtnExit = Util.texFromFile(graphicsDevice, Dir.dir + "GreenExit.bmp");

            btnPlay = new TextRenderableBordered(" ", new Rectangle(800, 50, 100, 30), font1, Color.Blue, Color.Wheat, 2);
            btnHelp = new TextRenderableBordered(" ", new Rectangle(800, 90, 100, 30), font1, Color.Blue, Color.Wheat, 2);
            btnExit = new TextRenderableBordered(" ", new Rectangle(800, 130, 100, 30), font1, Color.Blue, Color.Wheat, 2);
        }

        public override void Update(GameTime gameTime)
        {
            prevKeyState = keyState;
            keyState = Keyboard.GetState();

            prevMouseState = mouseState;
            mouseState = Mouse.GetState();

            mouseX = mouseState.X;
            mouseY = mouseState.Y;

            if(btnPlay.Contains(mouseX, mouseY) &&
               mouseState.LeftButton == ButtonState.Pressed &&
               prevMouseState.LeftButton != ButtonState.Pressed)
            {
                gameStateManager.setLevel(1);
            }

            if (btnHelp.Contains(mouseX, mouseY) &&
               mouseState.LeftButton == ButtonState.Pressed &&
               prevMouseState.LeftButton != ButtonState.Pressed)
            {
                gameStateManager.setLevel(5);
            }

            if (btnExit.Contains(mouseX, mouseY) &&
               mouseState.LeftButton == ButtonState.Pressed &&
               prevMouseState.LeftButton != ButtonState.Pressed)
            {
                //Exit
            }

        }

        public override void Draw(GameTime gameTime)
        {
                        
            //graphicsDevice.Clear(Color.Aqua);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);
            spriteBatch.Draw(texBackground, new Vector2(0, 0), Color.White);

            btnPlay.Draw(spriteBatch);
            btnHelp.Draw(spriteBatch);
            spriteBatch.Draw(texBtnPlay, new Vector2(800, 50), Color.White);
            spriteBatch.Draw(texBtnHelp, new Vector2(800, 90), Color.White);
            spriteBatch.Draw(texBtnExit, new Vector2(800, 130), Color.White);

            LineBatch.drawCross(spriteBatch, mouseX, mouseY, 5, Color.Red, Color.Red);
            spriteBatch.DrawString(font1, "There Is No War That Is Just                                               ", new Vector2(400, 50), Color.Black);
            spriteBatch.DrawString(font1, "But We Will Fight for What Our Fathers Fought for                          ", new Vector2(400, 70), Color.Black);
            spriteBatch.DrawString(font1, "For Family                                                                 ", new Vector2(400, 90), Color.Black);

            spriteBatch.End();
        }
    }
    
    // -------------------------------------------------------- Game level 1 ----------------------------------------------------------------------------------
    class GameLevel_1 : RC_GameStateParent
    {
        GraphicsDeviceManager graphics;
        AudioEngine audioEngine;
        SoundBank soundBank;
        WaveBank waveBank;

        Texture2D texBack = null;
        Texture2D texBoat = null;
        Texture2D texTorpedo = null;
        Texture2D texBoat1 = null;
        Texture2D texExplosion = null;
        Texture2D texWhale = null;
        Texture2D texBtnPause = null;

        MouseState mouseState;
        MouseState prevMouseState;
        int mouseX, mouseY;

        TextRenderableBordered btnPause = null;

        int boatSpeed = 3;
        float xx = 500;
        float yy = 630;
        float eboatyy = 500;
        float boatyy = 240;//boat y cordination on the water
        float torpedoSpeed = 2f;
        float pushBackStrength = 3f;
        float pushBackDistance = 10f; // bit above bounding radius

        Vector2 aimStart = new Vector2(0, 0); // torpedo aiming line
        Vector2 aimEnd = new Vector2(0, 0);
        int aimLineLength = 40;
        float iniAngle = 90;
        float aimSpeed = 0.5f;
        float aimEndX = 0;
        float aimEndY = 0;
        float aimX = 0;
        float aimY = 0;

        int noTorpedo = 10;
        int noBoat = 6;
        int Score = 0;
        int count = 0;
        int count1 = 0;
        int noWhale = 5;
        Random rnd = new Random();
        public static string dir = "";
        ImageBackground back1 = null;
        Sprite3 Torpedo = new Sprite3();
        Sprite3 sBoat = new Sprite3();
        Sprite3 sExplosion = new Sprite3();
        SpriteList slistBoat = new SpriteList();
        SpriteList slistEboat = new SpriteList();
        SpriteList slistWhale = new SpriteList();
        TextRenderableFlash r3a = null;
        TextRenderableFlash r2a = null;

        Sprite3 target = new Sprite3();
        Vector2 targetPos = new Vector2(500, 500);

        bool fireReady = true;
        bool fireReady1 = false;
        bool showbb = false;
        bool outofTorpe = false;
        bool moving = false;
        bool targetLock = false;

        KeyboardState kS, prevK;
        SillyFont16 sf16;
        SpriteFont font1;

        SoundEffect soundExplo;
        LimitSound limSoundExplo;

        public override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(graphicsDevice);
            int screenWidth = graphicsDevice.Viewport.Width;
            int ScreenHeight = graphicsDevice.Viewport.Height;
            Rectangle screenRect = new Rectangle(0, 0, screenWidth, ScreenHeight);

            LineBatch.init(graphicsDevice);
            dir = Util.findDirWithFile("Sea06.png");
            // TODO: use this.Content to load your game content here
            texBack = Util.texFromFile(graphicsDevice, dir + "Sea06.png");
            texBoat = Util.texFromFile(graphicsDevice, dir + "Uboat.png");
            texTorpedo = Util.texFromFile(graphicsDevice, dir + "Torpedo.png");
            texExplosion = Util.texFromFile(graphicsDevice, dir + "explode1.png");
            texWhale = Util.texFromFile(graphicsDevice, dir + "whale.png");
            sf16 = new SillyFont16(graphicsDevice, Color.Transparent, Color.Black);
            font1 = Content.Load<SpriteFont>("SpriteFont1");

            sBoat = new Sprite3(true, texBoat, xx, yy);
            sBoat.setHSoffset(new Vector2(texBoat.Width / 2, texBoat.Height / 2));

            // set up a list of boats on the water
            Sprite3 sp;
            texBoat1 = Util.texFromFile(graphicsDevice, dir + "boat1.png");
            sp = new Sprite3(true, texBoat1, 0, boatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width/2, texBoat1.Height / 2));
            slistBoat.addSpriteReuse(sp);
            texBoat1 = Util.texFromFile(graphicsDevice, dir + "boat2.png");
            sp = new Sprite3(true, texBoat1, 150, boatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width / 2, texBoat1.Height / 2));
            slistBoat.addSpriteReuse(sp);
            texBoat1 = Util.texFromFile(graphicsDevice, dir + "boat3.png");
            sp = new Sprite3(true, texBoat1, 300, boatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width / 2, texBoat1.Height / 2));
            slistBoat.addSpriteReuse(sp);
            texBoat1 = Util.texFromFile(graphicsDevice, dir + "boat4.png");
            sp = new Sprite3(true, texBoat1, 500, boatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width / 2, texBoat1.Height / 2));
            slistBoat.addSpriteReuse(sp);

            // set up a list of boats in the water

            texBoat1 = Util.texFromFile(graphicsDevice, dir + "eBoat1.png");
            sp = new Sprite3(true, texBoat1, 300, eboatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width / 2, texBoat1.Height / 2));
            slistEboat.addSpriteReuse(sp);
            texBoat1 = Util.texFromFile(graphicsDevice, dir + "eBoat2.png");
            sp = new Sprite3(true, texBoat1, 500, eboatyy);
            sp.setDeltaSpeed(new Vector2((float)1, 0));
            sp.setHSoffset(new Vector2(texBoat1.Width / 2, texBoat1.Height / 2));
            slistEboat.addSpriteReuse(sp);

            // Warning Flash
            r3a = new TextRenderableFlash("WARNING YOU ARE SPOTTED!", new Vector2(300, 150), font1, Color.Red, 30);
            r2a = new TextRenderableFlash("Solider! You Lost!", new Vector2(300, 150), font1, Color.Red, 30);
            r3a.setVisible(false);
            r2a.setVisible(false);

            // pause button
            texBtnPause = Util.texFromFile(graphicsDevice, Dir.dir + "GreenPause.bmp");
            btnPause = new TextRenderableBordered(" ", new Rectangle(500, 10, 100, 30), font1, Color.Blue, Color.Wheat, 2);

            //-------------------------------set up whales---------------------------------------------------------//
            for (int i = 0; i < noWhale; i++) {
                sp = new Sprite3(true, texWhale, (float)(rnd.NextDouble() * 800 + 100), (float)(rnd.NextDouble()*350+270));
                sp.setDeltaSpeed(new Vector2((float)(0.1 + rnd.NextDouble()), 0));
                sp.setWidthHeight(100, 50);
                sp.setWidthHeightOfTex(2100, 50);
                sp.setXframes(21);
                sp.setYframes(1);
                sp.setHSoffset(new Vector2(50, 25));
                sp.setBB(0, 0, 100, 50);
                //sp.setMoveAngleDegrees(0);
                //sp.setMoveSpeed(2.1f);
                Vector2[] seq1 = new Vector2[21];
                for (int j = 0;  j<= 20; j++) { seq1[j].X = j; seq1[j].Y = 0; }
                sp.setAnimationSequence(seq1, 0, 20, 5);
                sp.animationStart();
                slistWhale.addSpriteReuse(sp);
            }


            //------------------------------For the aim line------------------------------
            aimStart = new Vector2(sBoat.getPosX(), sBoat.getPosY());
            aimEndX = sBoat.getPosX();
            aimEndY = sBoat.getPosY()-aimLineLength;
            aimEnd = new Vector2(aimEndX,aimEndY);
            
            aimX= sBoat.getPosX();
            aimY = sBoat.getPosY() - 2000;
            //-----------------------------------------------------------------------------
            // sound effect
            //soundExplo = Content.Load<SoundEffect>("explosion22khz16pcm.wav");
            //limSoundExplo = new LimitSound(soundExplo, 3);
            
        }

        public override void Update(GameTime gameTime)
        {
            //------------------------------For Pause Button------------------------------
            prevKeyState = keyState;
            keyState = Keyboard.GetState();

            prevMouseState = mouseState;
            mouseState = Mouse.GetState();

            mouseX = mouseState.X;
            mouseY = mouseState.Y;
            if (btnPause.Contains(mouseX, mouseY) &&
                mouseState.LeftButton == ButtonState.Pressed &&
                prevMouseState.LeftButton != ButtonState.Pressed)
            {
                gameStateManager.pushLevel(3);
            }
            //-----------------------------------------------------------------------------



            sExplosion.animationTick(gameTime);
            //update all boats
            slistBoat.moveDeltaXY();
            for (int i = 0; i < slistBoat.count(); i++)
            {
                Sprite3 s = slistBoat.getSprite(i);
                if (s.getPosX() >= 1000)
                {
                    s.setPos(0, boatyy);
                }
            }
            slistEboat.moveDeltaXY();
            for (int i = 0; i < slistEboat.count(); i++)
            {
                Sprite3 s = slistEboat.getSprite(i);
                if (s.getPosX() >= 1000)
                {
                    s.setPos(0, eboatyy);
                }
            }

            // Collision test
            int collision = slistBoat.collisionAA(Torpedo);
            int collision1 = slistEboat.collisionAA(Torpedo);
            if (collision != -1 || collision1 != -1)
            {
                noBoat--;
                Score = Score + 200;
                Torpedo.setActive(false);
                fireReady = true;
                targetLock = false;
                if (collision != -1)
                {
                    Sprite3 c = slistBoat.getSprite(collision);
                    c.setActive(false);
                }
                else
                {
                    Sprite3 c = slistEboat.getSprite(collision1);
                    c.setActive(false);
                }
                // Animation of Explosion & Sound Effect
                audioEngine = new AudioEngine("Content/sound.xgs");
                soundBank = new SoundBank(audioEngine, "Content/Sound Bank.xsb");
                waveBank = new WaveBank(audioEngine, "Content/Wave Bank.xwb");
                soundBank.GetCue("explosion").Play();


                sExplosion = new Sprite3(true, texExplosion, Torpedo.getPosX() - 32, Torpedo.getPosY() - 64);
                sExplosion.setXframes(16);
                sExplosion.setYframes(1);
                sExplosion.setWidthHeight(64, 64);
                Vector2[] seq = new Vector2[16];
                for (int i = 0; i <= 15; i++) { seq[i].X = i; seq[i].Y = 0; }
                sExplosion.setAnimationSequence(seq, 0, 15, 5);
                sExplosion.animationStart();
                sExplosion.setAnimFinished(2);

            }


            //-------------update whales ----------
            for (int i = 0; i < noWhale; i++)
            {
                Sprite3 s = slistWhale.getSprite(i);
                if (s.getPosX() >= 1000)
                {
                    s.flip= SpriteEffects.FlipHorizontally;
                    s.setDeltaSpeed(-s.getDeltaSpeed());
                }

                if (s.getPosX() <= 0)
                {
                    s.flip = SpriteEffects.None;
                    s.setDeltaSpeed(-s.getDeltaSpeed());
                }

            }


            slistWhale.moveDeltaXY();
            slistWhale.animationTick(gameTime);


            // Torpedo Out of Boundary
            if (Torpedo.getPosY() < boatyy)
            {
                Torpedo.setActive(false);
                fireReady = true;
            }
            // show bounding box
            prevK = kS;
            kS = Keyboard.GetState();
            if (kS.IsKeyDown(Keys.B) && prevK.IsKeyUp(Keys.B)) // ***
            {
                showbb = !showbb;
            }

            // ------------------------------- update the Uboat -------------------------------
            if (kS.IsKeyDown(Keys.Right))
            {
                if (prevK.IsKeyUp(Keys.Left)) { sBoat.flip = SpriteEffects.None; }
                aimEndX=aimEndX + boatSpeed; aimX = aimX + boatSpeed;
                aimEnd = new Vector2(aimEndX, aimEndY);
                xx = xx + boatSpeed;
                
            }
            else if (kS.IsKeyDown(Keys.Left))
            {
                if (prevK.IsKeyUp(Keys.Right)) { sBoat.flip = SpriteEffects.FlipHorizontally; }
                aimEndX = aimEndX - boatSpeed; aimX = aimX - boatSpeed;
                aimEnd = new Vector2(aimEndX, aimEndY);
                xx = xx - boatSpeed;
            }
            if (xx >= 1000 ) { xx = 1000; aimEndX = 1000; }
            if (xx <= 0) { xx = 0; aimEndX = 0; };

            //-------------------------------update the torpedo -------------------------------
            if (outofTorpe == false)
            {
                if (moving) moveTorpedo();
                if (kS.IsKeyDown(Keys.Space) && prevK.IsKeyUp(Keys.Space) && fireReady )
                {
                    noTorpedo--;
                    if (noTorpedo == 0) { outofTorpe = true; }
                    fireReady = false;
                    Torpedo = new Sprite3(true, texTorpedo, xx, yy);
                    Torpedo.setHSoffset(new Vector2(texTorpedo.Width / 2, texTorpedo.Height / 2));
                    Torpedo.boundingSphereRadius =20f;
                    Torpedo.setDisplayAngleOffset((float)Math.PI/2 );
                    //Torpedo.setPos(xx+texBoat.Width/2, yy);
                    //Torpedo.setDeltaSpeed(new Vector2(0, -torpedoSpeed));
                    moving = true;
                    targetLock = true;
                }
            }
            Torpedo.savePosition();
            Torpedo.moveByDeltaXY();

            //------------------------------update the aim line------------------------------
            aimStart = new Vector2(sBoat.getPosX(), sBoat.getPosY());
            if (keyState.IsKeyDown(Keys.D) )
            {
                iniAngle = iniAngle - aimSpeed;
                aimEndX = sBoat.getPosX() + (float)Math.Cos(Math.PI * iniAngle / 180) * aimLineLength;
                aimEndY = sBoat.getPosY() - (float)Math.Sin(Math.PI * iniAngle / 180) * aimLineLength;

                aimX= sBoat.getPosX() + (float)Math.Cos(Math.PI * iniAngle / 180) * 2000;
                aimY = sBoat.getPosY() - (float)Math.Sin(Math.PI * iniAngle / 180) * 2000;

                aimEnd = new Vector2(aimEndX, aimEndY);
            }
            else if (keyState.IsKeyDown(Keys.A))
            {
                iniAngle = iniAngle + aimSpeed;
                aimEndX = sBoat.getPosX() + (float)Math.Cos(Math.PI * iniAngle / 180) * aimLineLength;
                aimEndY = sBoat.getPosY() - (float)Math.Sin(Math.PI * iniAngle / 180) * aimLineLength;

                aimX = sBoat.getPosX() + (float)Math.Cos(Math.PI * iniAngle / 180) * 2000;
                aimY = sBoat.getPosY() - (float)Math.Sin(Math.PI * iniAngle / 180) * 2000;

                aimEnd = new Vector2(aimEndX, aimEndY);
            }
            //-----------------------------------------------------------------------------
            if (targetLock != true)
            {
                findTarget();
            }
            targetPos = target.getPos();

            //-------------------------------------next level-----------

            if (Score >=1000)
            {
                r3a.setVisible(true);
                r3a.Update(gameTime);
                count++;
                audioEngine = new AudioEngine("Content/sound.xgs");
                soundBank = new SoundBank(audioEngine, "Content/Sound Bank.xsb");
                waveBank = new WaveBank(audioEngine, "Content/Wave Bank.xwb");
                soundBank.GetCue("warning4").Play();
            }
            if (count == 240) { gameStateManager.setLevel(2); }

            if (noTorpedo == 0) { count1++;
                r2a.setVisible(true);
                r2a.Update(gameTime);
            }
            if (count1 == 240) { gameStateManager.setLevel(0); }


            sBoat.setPos(xx, yy);
            base.Update(gameTime);
        }

        //------------------------------update the target------------------------------
        double x = 0;
        double y = 0;
        void findTarget() {
            for (int i = 0;i <= slistBoat.count()-1; i++){
                //int aa = slistBoat.countActive();
                Sprite3 ss = slistBoat.getSprite(i);
                Rectangle bb = ss.getBoundingBoxAA();
                int rc = 1;
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y, bb.X + bb.Width, bb.Y);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y, bb.X, bb.Y + bb.Height);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X + bb.Width, bb.Y, bb.X + bb.Width, bb.Y + bb.Height);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y + bb.Height, bb.X + bb.Width, bb.Y + bb.Height);
                if (rc==0)
                {
                    ss.setColor(Color.Blue);
                    fireReady1 = true;
                    if (targetLock != true) { 
                        target = ss;
                    }
                    //s3.setDeltaSpeed(new Vector2(0, 0));
                }
                else { 
                    ss.setColor(Color.White);
                    fireReady1 = false;
                }
            }

            for (int i = 0; i <= slistEboat.count() - 1; i++)
            {
                //int aa = slistBoat.countActive();
                Sprite3 ss = slistEboat.getSprite(i);
                Rectangle bb = ss.getBoundingBoxAA();
                int rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y, bb.X + bb.Width, bb.Y);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y, bb.X, bb.Y + bb.Height);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X + bb.Width, bb.Y, bb.X + bb.Width, bb.Y + bb.Height);
                rc = Util.intersect2D(ref x, ref y, aimStart.X, aimStart.Y, aimX, aimY, bb.X, bb.Y + bb.Height, bb.X + bb.Width, bb.Y + bb.Height);
                if (rc == 0)
                {
                    ss.setColor(Color.Blue); fireReady1 = true;
                    if (targetLock != true)
                    {
                        target = ss;
                    }
                    //s3.setDeltaSpeed(new Vector2(0, 0));
                }
                else
                {
                    ss.setColor(Color.White); fireReady1 = false;

                }
            }



        }
        



        //-----------------------------------move torpedo---------------------------------
        void moveTorpedo()
        {
            
            // first compute the  dx,dy vector at 'speed'
            Vector2 torpedoPos = Torpedo.getPos();
            Vector2 baseDelta = targetPos - torpedoPos;
            Vector2 moveDelta = baseDelta / baseDelta.Length();
            moveDelta = moveDelta * torpedoSpeed;
            //Vector2 newTorpedoPos = torpedoPos + moveDelta;
            // now compute a vector to push back from the whales
            Vector2 pushBack = new Vector2(0, 0);

            for (int i = 0; i <= slistWhale.highUsed; i++) {
                Sprite3 ss = slistWhale.getSprite(i);
                ss.boundingSphereRadius = 56;
                if (ss == null) continue;
                if (!ss.getVisible()) continue;
                if (!ss.active) continue;
                float pushBackDist = pushBackDistance + ss.boundingSphereRadius + Torpedo.boundingSphereRadius;

                Vector2 pp = ss.getPos();
                if ((pp - torpedoPos).Length() < pushBackDist)
                {
                    Vector2 pb = (pp - torpedoPos);
                    float dist = pb.Length();
                    float amt = (pushBackDist - dist) / pushBackDist;
                    amt = amt * pushBackStrength;// amount of push back (checked with debugger)
                    pb = pb / dist;
                    pushBack = pb * (-1);
                    //Vector2 pushAway = new Vector2(1, 0);
                    //newTorpedoPos = torpedoPos + pushAway * torpedoSpeed;
                }
            }
            Vector2 newTorpedoPos = torpedoPos + moveDelta + pushBack;
            Torpedo.setPos(newTorpedoPos);
            Torpedo.alignDisplayAngle();
            //Torpedo.setMoveAngleDegrees(1.6f);
            //if ((newTorpedoPos - target).Length() <= torpedoSpeed) moving = false;


        }
        public override void Draw(GameTime gameTime)
        {
            graphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            spriteBatch.Draw(texBack, new Vector2(0, 0), Color.White);
            //spriteBatch.Draw(sBoat, new Vector2(xx, yy), Color.White);

            //-----------------------------------pause button------------------------
            btnPause.Draw(spriteBatch);
            spriteBatch.Draw(texBtnPause, new Vector2(500, 10), Color.White);
            LineBatch.drawCross(spriteBatch, mouseX, mouseY, 5, Color.Red, Color.Red);
            //----------------------------------------------------------------------
            sBoat.Draw(spriteBatch);
            LineBatch.drawLine(spriteBatch, Color.Black, aimStart, aimEnd);

            Torpedo.Draw(spriteBatch);
            sExplosion.Draw(spriteBatch);
            slistWhale.drawActive(spriteBatch);
            slistBoat.drawActive(spriteBatch);
            slistEboat.drawActive(spriteBatch);
            if (showbb)
            {
                Torpedo.drawBB(spriteBatch, Color.Black);
                Torpedo.drawHS(spriteBatch, Color.Green);
                slistBoat.drawInfo(spriteBatch, Color.Red, Color.Blue);
                slistEboat.drawInfo(spriteBatch, Color.Red, Color.Blue);

                slistWhale.drawInfo(spriteBatch, Color.Red, Color.Blue);
                slistWhale.drawInfo(spriteBatch, Color.Red, Color.Blue);
            }


            //sf16.drawString(spriteBatch, "The Number of Torpedos Left: ", new Vector2(30, 30), Color.Black);
            spriteBatch.DrawString(font1, "The Number of Torpedos Left: ", new Vector2(10, 30), Color.Black);
            spriteBatch.DrawString(font1, noTorpedo.ToString(), new Vector2(240, 30), Color.Red);
            spriteBatch.DrawString(font1, "Score: ", new Vector2(10, 60), Color.Black);
            spriteBatch.DrawString(font1, Score.ToString(), new Vector2(70, 60), Color.Red);
            r3a.Draw(spriteBatch);
            spriteBatch.End();
            // TODO: Add your drawing code here

            //base.Draw(gameTime);
        }
    }

    // -------------------------------------------------------- Game level 2 ----------------------------------------------------------------------------------

    class GameLevel_2 : RC_GameStateParent
    {
        SpriteList slistBomb = new SpriteList();
        Sprite3 sBoat = new Sprite3();
        Sprite3 sJet = new Sprite3();
        Sprite3 sExplosion = new Sprite3();

        Texture2D texBackground = null;
        Texture2D texBoat = null;
        Texture2D texJet = null;
        Texture2D texBomb = null;
        Texture2D texExplosion = null;

        int count;
        bool boolCount = false;
        KeyboardState kS, prevK;
        int boatSpeed = 3;

        float xx = 500;
        float yy = 630;
        float xjet = 10;
        float yjet = 20;

        int numOfTorpedo = 10;
        int noOFtorpedo = 0;
        float torpedoInter = 1000/11;
        //float torpedoFire = 500 / 7;
        Boolean iflag = true;
        Random RandomClass;

        bool showbb = false;
        public override void LoadContent()
        {
            RandomClass = new Random();

            font1 = Content.Load<SpriteFont>("Fonty");
            texBackground = Util.texFromFile(graphicsDevice, Dir.dir + "Sea06.png");
            texBoat = Util.texFromFile(graphicsDevice, Dir.dir + "Uboat.png");
            texJet = Util.texFromFile(graphicsDevice, Dir.dir + "jet.png");
            texExplosion = Util.texFromFile(graphicsDevice, Dir.dir + "explode1.png");


            sBoat = new Sprite3(true, texBoat, xx, yy);
            sJet = new Sprite3(true, texJet, xjet, yjet);

            // assign bombs together

            for (int i=0; i<=numOfTorpedo+1; i++) { 
                Sprite3 sp;
                texBomb = Util.texFromFile(graphicsDevice, Dir.dir + "bomb.png");
                sp = new Sprite3(true, texBomb, 0, 0);
                sp.setHSoffset(new Vector2(texBomb.Width / 2, texBomb.Height / 2));
                sp.setDeltaSpeed(new Vector2((float)0, (float)1));
                sp.visible = false;
                slistBomb.addSpriteReuse(sp);
            }

        }

        public override void Update(GameTime gameTime)
        {
            prevKeyState = keyState;
            sJet.setDeltaSpeed(new Vector2((float)1.5, 0));
            sJet.savePosition();
            sJet.moveByDeltaXY();
            if (sJet.getPosX() >= 1000) { sJet.visible = false; }

            
            if (sJet.getPosX() > torpedoInter && iflag) {
                slistBomb.getSprite(noOFtorpedo).visible = true;
                slistBomb.getSprite(noOFtorpedo).setPos(sJet.getPosX(),sJet.getPosY());

                noOFtorpedo++;
                torpedoInter = torpedoInter + 1000 / 11;
                if (noOFtorpedo > 11) { iflag = false; }

            }

            for (int i=0; i<=numOfTorpedo+1; i++)
            {
                if (slistBomb.getSprite(i).getPosY()> 700)
                {
                    //slistBomb.getSprite(i).setActive(false);
                    slistBomb.getSprite(i).visible = false;
                }
            }
            slistBomb.moveDeltaXY();

            // -----------------------------------update the Uboat-------------------------
            prevK = kS;
            kS = Keyboard.GetState();
            if (kS.IsKeyDown(Keys.Right))
            {
                if (prevK.IsKeyUp(Keys.Left)) { sBoat.flip = SpriteEffects.None; }

                xx = xx + boatSpeed;
            }
            else if (kS.IsKeyDown(Keys.Left))
            {
                if (prevK.IsKeyUp(Keys.Right)) { sBoat.flip = SpriteEffects.FlipHorizontally; }

                xx = xx - boatSpeed;
            }
            if (xx >= 1000 - texBoat.Width) { xx = 1000 - texBoat.Width; }
            if (xx <= 0) { xx = 0; };
            sBoat.setPos(xx, yy);
            base.Update(gameTime);

            //---------------------------------show boudning box---------
            if (kS.IsKeyDown(Keys.B) && prevK.IsKeyUp(Keys.B)) // ***
            {
                showbb = !showbb;
            }

            //-------------------------------collosion --------------------------
            // Collision test
            int collision = slistBomb.collisionAA(sBoat);
            sExplosion.animationTick(gameTime);
            if (collision != -1 )
            {
                sBoat.setActive(false);
                Sprite3 c = slistBomb.getSprite(collision);
                c.setActive(false);


                // Animation of Explosion & Sound Effect
                //limSoundExplo.playSoundIfOk();
                sExplosion = new Sprite3(true, texExplosion, sBoat.getPosX() + 20, sBoat.getPosY()-64);
                sExplosion.setXframes(16);
                sExplosion.setYframes(1);
                sExplosion.setWidthHeight(64, 64);
                Vector2[] seq = new Vector2[16];
                for (int i = 0; i <= 15; i++) { seq[i].X = i; seq[i].Y = 0; }
                sExplosion.setAnimationSequence(seq, 0, 15, 5);
                sExplosion.animationStart();
                sExplosion.setAnimFinished(2);

                boolCount = true;
            }

            if (boolCount) {
                count++;
                if (count == 240) { gameStateManager.setLevel(4); }
            }


        }

        public override void Draw(GameTime gameTime)
        {
            graphicsDevice.Clear(Color.Chartreuse);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);
            spriteBatch.Draw(texBackground, new Vector2(0, 0), Color.White);

            sExplosion.Draw(spriteBatch);
            slistBomb.drawActive(spriteBatch);
            sBoat.Draw(spriteBatch);
            sJet.Draw(spriteBatch);

            if (showbb)
            {
                sBoat.drawBB(spriteBatch, Color.Black);
                sBoat.drawHS(spriteBatch, Color.Green);
                slistBomb.drawInfo(spriteBatch, Color.Red, Color.Blue);
                //slistEboat.drawInfo(spriteBatch, Color.Red, Color.Blue);
            }

            spriteBatch.End();
        }
    }
    
    // -------------------------------------------------------- Game level 3 ----------------------------------------------------------------------------------

    class GameLevel_3_Pause : RC_GameStateParent
    {
        Texture2D texBackground = null;
        Texture2D texBtnResume = null;
        Texture2D texResumePic = null;
        MouseState mouseState;
        MouseState prevMouseState;
        int mouseX, mouseY;

        TextRenderableFlash flashHurry = null;
        TextRenderableBordered btnResume = null;

        public override void LoadContent()
        {
            LineBatch.init(graphicsDevice);

            texBackground = Util.texFromFile(graphicsDevice, Dir.dir + "Sea06.png");
            texBtnResume = Util.texFromFile(graphicsDevice, Dir.dir + "GreenResume.bmp");
            texResumePic = Util.texFromFile(graphicsDevice, Dir.dir + "pauseImage.jpg");
            btnResume = new TextRenderableBordered(" ", new Rectangle(500, 50, 100, 30), font1, Color.Blue, Color.Wheat, 2);

            flashHurry = new TextRenderableFlash("SOLDIER! LETS MOVE! MOVE!", new Vector2(430, 350), font1, Color.Red, 30);
        }

        public override void Update(GameTime gameTime)
        {
            prevKeyState = keyState;
            keyState = Keyboard.GetState();

            prevMouseState = mouseState;
            mouseState = Mouse.GetState();

            mouseX = mouseState.X;
            mouseY = mouseState.Y;

            if (btnResume.Contains(mouseX, mouseY) &&  mouseState.LeftButton == ButtonState.Pressed &&
               prevMouseState.LeftButton != ButtonState.Pressed)
            {
                gameStateManager.popLevel();
            }

            flashHurry.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            graphicsDevice.Clear(Color.White);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);
            //spriteBatch.Draw(texBackground, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(texResumePic, new Vector2(50, 50), Color.White);

            btnResume.Draw(spriteBatch);
            spriteBatch.Draw(texBtnResume, new Vector2(500, 50), Color.White);
            LineBatch.drawCross(spriteBatch, mouseX, mouseY, 5, Color.Red, Color.Red);

            flashHurry.Draw(spriteBatch);
            spriteBatch.End();
        }

    }


    // -------------------------------------------------------- Game level 4 ----------------------------------------------------------------------------------

    class GameLevel_4 : RC_GameStateParent
    {
        Texture2D texBackground = null;
        Texture2D texClose= null;
        TextureFade r4c = null;

        int count;

        public override void LoadContent()
        {
            LineBatch.init(graphicsDevice);

            texBackground = Util.texFromFile(graphicsDevice, Dir.dir + "Sea06.png");
            texClose = Util.texFromFile(graphicsDevice, Dir.dir + "gameComplete1.png");
            r4c = new TextureFade(texClose, new Rectangle(100, 300, 500, 80), new Rectangle(500, 300, 500, 80), Color.White, new Color(0, 0, 60, 0), 500);

        }

        public override void Update(GameTime gameTime)
        {
            r4c.Update(gameTime);
            count++;
            if (count >= 240) {
                gameStateManager.setLevel(0); ; }

        }

        public override void Draw(GameTime gameTime)
        {
            graphicsDevice.Clear(Color.White);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);


            r4c.Draw(spriteBatch);
            spriteBatch.End();
        }
    }

    // -------------------------------------------------------- Game level 5 ----------------------------------------------------------------------------------
    class GameLevel_5 : RC_GameStateParent
    {
        Texture2D texBackground = null;
        Texture2D texBtnResume = null;
        Texture2D texResumePic = null;
        MouseState mouseState;
        MouseState prevMouseState;
        int mouseX, mouseY;

        TextRenderableFlash flashHurry = null;
        TextRenderableBordered btnResume = null;

        public override void LoadContent()
        {
            LineBatch.init(graphicsDevice);

            texBackground = Util.texFromFile(graphicsDevice, Dir.dir + "Sea06.png");
            texBtnResume = Util.texFromFile(graphicsDevice, Dir.dir + "GreenResume.bmp");
            btnResume = new TextRenderableBordered(" ", new Rectangle(800, 50, 100, 30), font1, Color.Blue, Color.Wheat, 2);

        }

        public override void Update(GameTime gameTime)
        {
            prevKeyState = keyState;
            keyState = Keyboard.GetState();

            prevMouseState = mouseState;
            mouseState = Mouse.GetState();

            mouseX = mouseState.X;
            mouseY = mouseState.Y;

            if (btnResume.Contains(mouseX, mouseY) && mouseState.LeftButton == ButtonState.Pressed &&
               prevMouseState.LeftButton != ButtonState.Pressed)
            {
                gameStateManager.setLevel(0);
            }

        }

        public override void Draw(GameTime gameTime)
        {
            graphicsDevice.Clear(Color.White);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);

            btnResume.Draw(spriteBatch);
            spriteBatch.Draw(texBtnResume, new Vector2(800, 50), Color.White);
            LineBatch.drawCross(spriteBatch, mouseX, mouseY, 5, Color.Red, Color.Red);

            spriteBatch.DrawString(font1, "Use A or D Key to guid the aim system for the submarine                              ", new Vector2(100, 410), Color.Black);
            spriteBatch.DrawString(font1, "Use right and left key to move the submarine                               ", new Vector2(100, 430), Color.Black);
            spriteBatch.DrawString(font1, "Use the space button to fire torpedo                                       ", new Vector2(100, 450), Color.Black);
            spriteBatch.DrawString(font1, "If the scores are over 1000, you will be eligible for next level                                       ", new Vector2(100, 470), Color.Black);

            spriteBatch.End();
        }
    }

}
